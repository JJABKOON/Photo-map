import React, { useState, useEffect, useRef } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, Modal,
  TextInput, ScrollView, Image, Alert, Platform,
  Dimensions, ActivityIndicator, KeyboardAvoidingView, WebView,
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import * as Location from 'expo-location';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { StatusBar } from 'expo-status-bar';
import DateTimePickerModal from 'react-native-modal-datetime-picker';
import { WebView as RNWebView } from 'react-native-webview';

const { width, height } = Dimensions.get('window');
const STORAGE_KEY = '@photo_map_v2';

const C = {
  bg: '#0f0f1a', surface: '#1a1a2e', card: '#16213e',
  accent: '#e94560', text: '#e8e8f0', muted: '#8888aa',
  border: '#2a2a4a', success: '#4ecca3',
};

export default function App() {
  const webViewRef = useRef(null);
  const [photos, setPhotos] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [tab, setTab] = useState('map');
  const [showAdd, setShowAdd] = useState(false);
  const [showDetail, setShowDetail] = useState(false);
  const [showFilter, setShowFilter] = useState(false);
  const [selected, setSelected] = useState(null);
  const [pendingImg, setPendingImg] = useState(null);
  const [pendingLoc, setPendingLoc] = useState(null);
  const [pinMode, setPinMode] = useState(false);
  const [title, setTitle] = useState('');
  const [address, setAddress] = useState('');
  const [memo, setMemo] = useState('');
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);
  const [showStart, setShowStart] = useState(false);
  const [showEnd, setShowEnd] = useState(false);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(false);
  const [mapReady, setMapReady] = useState(false);
  const [currentLat, setCurrentLat] = useState(37.5665);
  const [currentLng, setCurrentLng] = useState(126.9780);

  useEffect(() => { init(); }, []);
  useEffect(() => { applyFilter(); }, [photos, startDate, endDate, search]);
  useEffect(() => {
    if (mapReady) updateMapMarkers();
  }, [filtered, mapReady]);

  const init = async () => {
    const data = await AsyncStorage.getItem(STORAGE_KEY);
    if (data) setPhotos(JSON.parse(data));
    const { status } = await Location.requestForegroundPermissionsAsync();
    if (status === 'granted') {
      const loc = await Location.getCurrentPositionAsync({});
      setCurrentLat(loc.coords.latitude);
      setCurrentLng(loc.coords.longitude);
    }
    await ImagePicker.requestMediaLibraryPermissionsAsync();
  };

  const save = async (list) => {
    setPhotos(list);
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(list));
  };

  const applyFilter = () => {
    let r = [...photos];
    if (startDate) r = r.filter(p => new Date(p.date) >= startDate);
    if (endDate) { const e = new Date(endDate); e.setHours(23,59,59); r = r.filter(p => new Date(p.date) <= e); }
    if (search.trim()) { const q = search.toLowerCase(); r = r.filter(p => (p.title+p.address+p.memo).toLowerCase().includes(q)); }
    setFiltered(r);
  };

  const updateMapMarkers = () => {
    if (!webViewRef.current) return;
    const markers = filtered.map(p => ({
      id: p.id, lat: p.latitude, lng: p.longitude,
      title: p.title, uri: p.uri,
    }));
    webViewRef.current.injectJavaScript(`updateMarkers(${JSON.stringify(markers)}); true;`);
  };

  const pickImage = async () => {
    setLoading(true);
    try {
      const r = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        quality: 0.7, exif: true,
      });
      if (!r.canceled && r.assets[0]) {
        const asset = r.assets[0];
        const exif = asset.exif || {};
        const lat = exif.GPSLatitude;
        const lng = exif.GPSLongitude;
        setPendingImg(asset.uri);
        if (lat && lng) {
          setPendingLoc({ latitude: parseFloat(lat), longitude: parseFloat(lng) });
          setTitle(''); setAddress(''); setMemo('');
          setShowAdd(true);
        } else {
          Alert.alert('위치 없음', '위치를 어떻게 설정할까요?', [
            { text: '지도에서 선택', onPress: () => { setPinMode(true); setTab('map'); } },
            { text: '주소 입력', onPress: () => { setTitle(''); setAddress(''); setMemo(''); setShowAdd(true); } },
            { text: '취소', style: 'cancel', onPress: () => setPendingImg(null) },
          ]);
        }
      }
    } catch(e) { Alert.alert('오류', '사진 불러오기 실패'); }
    setLoading(false);
  };

  const geocode = async (addr) => {
    try {
      const r = await fetch(`https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(addr)}&format=json&limit=1`, { headers: {'Accept-Language':'ko','User-Agent':'PhotoMapApp/1.0'} });
      const d = await r.json();
      if (d.length) return { latitude: parseFloat(d[0].lat), longitude: parseFloat(d[0].lon) };
    } catch(e) {}
    return null;
  };

  const reverseGeocode = async (lat, lng) => {
    try {
      const r = await fetch(`https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lng}&format=json`, { headers: {'Accept-Language':'ko','User-Agent':'PhotoMapApp/1.0'} });
      const d = await r.json();
      return d.display_name || '';
    } catch(e) { return ''; }
  };

  const savePhoto = async () => {
    let loc = pendingLoc;
    if (!loc && address.trim()) {
      setLoading(true);
      loc = await geocode(address);
      setLoading(false);
      if (!loc) { Alert.alert('주소 오류', '주소를 찾을 수 없습니다'); return; }
    }
    if (!loc) { Alert.alert('위치 필요', '위치를 설정해주세요'); return; }
    if (!pendingImg) { Alert.alert('사진 필요'); return; }
    let addr = address;
    if (!addr.trim()) addr = await reverseGeocode(loc.latitude, loc.longitude);
    const p = {
      id: Date.now().toString(), uri: pendingImg,
      latitude: loc.latitude, longitude: loc.longitude,
      title: title.trim() || `사진 ${photos.length+1}`,
      address: addr, memo, date: new Date().toISOString(),
    };
    const updated = [p, ...photos];
    await save(updated);
    setShowAdd(false); setPendingImg(null); setPendingLoc(null);
    setTitle(''); setAddress(''); setMemo('');
    if (webViewRef.current) {
      webViewRef.current.injectJavaScript(`flyTo(${loc.latitude}, ${loc.longitude}); true;`);
    }
  };

  const deletePhoto = (id) => {
    Alert.alert('삭제', '삭제하시겠어요?', [
      { text: '삭제', style: 'destructive', onPress: async () => {
        const updated = photos.filter(p => p.id !== id);
        await save(updated); setShowDetail(false);
      }},
      { text: '취소', style: 'cancel' },
    ]);
  };

  const onMessage = (e) => {
    try {
      const data = JSON.parse(e.nativeEvent.data);
      if (data.type === 'mapClick' && pinMode) {
        setPendingLoc({ latitude: data.lat, longitude: data.lng });
        setPinMode(false);
        setTitle(''); setAddress(''); setMemo('');
        setShowAdd(true);
      } else if (data.type === 'markerClick') {
        const photo = photos.find(p => p.id === data.id);
        if (photo) { setSelected(photo); setShowDetail(true); }
      } else if (data.type === 'ready') {
        setMapReady(true);
      }
    } catch(e) {}
  };

  const fmt = (iso) => {
    const d = new Date(iso);
    return `${d.getFullYear()}.${String(d.getMonth()+1).padStart(2,'0')}.${String(d.getDate()).padStart(2,'0')}`;
  };

  const mapHTML = `<!DOCTYPE html>
<html><head>
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"/>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<style>
  * { margin:0; padding:0; box-sizing:border-box; }
  html,body,#map { width:100%; height:100%; background:#0f0f1a; }
  .custom-marker { background:none; border:none; }
  .marker-wrap { display:flex; flex-direction:column; align-items:center; }
  .marker-img { width:44px; height:44px; border-radius:8px; border:2px solid #fff; object-fit:cover; box-shadow:0 2px 8px rgba(0,0,0,0.5); }
  .marker-pin { width:2px; height:8px; background:#e94560; }
  .pin-cursor { cursor:crosshair; }
</style>
</head><body>
<div id="map"></div>
<script>
var map = L.map('map', { zoomControl:true }).setView([${currentLat}, ${currentLng}], 12);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  attribution:'OpenStreetMap', maxZoom:19
}).addTo(map);

var markers = {};
var pinMode = false;

map.on('click', function(e) {
  window.ReactNativeWebView.postMessage(JSON.stringify({
    type: 'mapClick', lat: e.latlng.lat, lng: e.latlng.lng
  }));
});

function updateMarkers(list) {
  Object.values(markers).forEach(m => map.removeLayer(m));
  markers = {};
  list.forEach(function(p) {
    var icon = L.divIcon({
      className: 'custom-marker',
      html: '<div class="marker-wrap"><img class="marker-img" src="'+p.uri+'" onerror="this.src=\\'data:image/svg+xml,<svg xmlns=\\"http://www.w3.org/2000/svg\\" viewBox=\\"0 0 44 44\\"><rect width=\\"44\\" height=\\"44\\" rx=\\"8\\" fill=\\"%23e94560\\"/><text x=\\"22\\" y=\\"28\\" text-anchor=\\"middle\\" font-size=\\"20\\">📍</text></svg>\\'"/><div class="marker-pin"></div></div>',
      iconSize: [44, 54], iconAnchor: [22, 54],
    });
    var m = L.marker([p.lat, p.lng], {icon: icon}).addTo(map);
    m.on('click', function(e) {
      L.DomEvent.stopPropagation(e);
      window.ReactNativeWebView.postMessage(JSON.stringify({type:'markerClick', id:p.id}));
    });
    markers[p.id] = m;
  });
}

function flyTo(lat, lng) {
  map.flyTo([lat, lng], 15, {duration:1});
}

window.ReactNativeWebView.postMessage(JSON.stringify({type:'ready'}));
</script>
</body></html>`;

  const filterCount = (startDate?1:0)+(endDate?1:0)+(search?1:0);

  return (
    <View style={s.container}>
      <StatusBar style="light"/>

      {/* 헤더 */}
      <View style={s.header}>
        <View>
          <Text style={s.htitle}>📍 포토맵</Text>
          <Text style={s.hsub}>{filtered.length}개</Text>
        </View>
        <View style={s.hbtns}>
          <TouchableOpacity style={[s.ibtn, filterCount>0&&s.ibtnOn]} onPress={()=>setShowFilter(true)}>
            <Text style={s.ibtxt}>🔍</Text>
            {filterCount>0&&<View style={s.badge}><Text style={s.badgeTxt}>{filterCount}</Text></View>}
          </TouchableOpacity>
          <TouchableOpacity style={[s.ibtn, pinMode&&s.ibtnOn]} onPress={()=>{setPendingImg(null);setPinMode(!pinMode);if(!pinMode)Alert.alert('📌 핀 모드','지도를 탭해서 위치를 선택하세요');}}>
            <Text style={s.ibtxt}>📌</Text>
          </TouchableOpacity>
          <TouchableOpacity style={s.addbtn} onPress={pickImage} disabled={loading}>
            {loading?<ActivityIndicator color="#fff" size="small"/>:<Text style={s.addtxt}>+ 사진</Text>}
          </TouchableOpacity>
        </View>
      </View>

      {/* 탭 */}
      <View style={s.tabs}>
        <TouchableOpacity style={[s.tab, tab==='map'&&s.tabOn]} onPress={()=>setTab('map')}>
          <Text style={[s.tabtxt, tab==='map'&&s.tabtxtOn]}>🗺 지도</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[s.tab, tab==='list'&&s.tabOn]} onPress={()=>setTab('list')}>
          <Text style={[s.tabtxt, tab==='list'&&s.tabtxtOn]}>📋 목록</Text>
        </TouchableOpacity>
      </View>

      {pinMode&&<View style={s.pinBanner}><Text style={s.pinTxt}>📍 지도를 탭하여 위치 선택</Text><TouchableOpacity onPress={()=>setPinMode(false)}><Text style={s.pinCancel}>취소</Text></TouchableOpacity></View>}

      {/* 지도 */}
      {tab==='map'&&(
        <RNWebView
          ref={webViewRef}
          style={s.map}
          source={{ html: mapHTML }}
          onMessage={onMessage}
          javaScriptEnabled
          domStorageEnabled
          originWhitelist={['*']}
          mixedContentMode="always"
          allowFileAccess
          onLoad={()=>{ if(filtered.length>0) setTimeout(updateMapMarkers, 500); }}
        />
      )}

      {/* 목록 */}
      {tab==='list'&&(
        <ScrollView style={s.list} contentContainerStyle={{paddingBottom:20}}>
          {filtered.length===0?(
            <View style={s.empty}>
              <Text style={{fontSize:60,marginBottom:12}}>🏞</Text>
              <Text style={s.emptyT}>사진이 없습니다</Text>
              <Text style={s.emptyD}>+ 사진 버튼으로 추가해보세요</Text>
            </View>
          ):filtered.map(p=>(
            <TouchableOpacity key={p.id} style={s.item} onPress={()=>{setSelected(p);setShowDetail(true);}}>
              <Image source={{uri:p.uri}} style={s.thumb}/>
              <View style={s.info}>
                <Text style={s.ititle} numberOfLines={1}>{p.title}</Text>
                <Text style={s.iaddr} numberOfLines={2}>{p.address||'주소 없음'}</Text>
                <Text style={s.idate}>{fmt(p.date)}</Text>
              </View>
              <TouchableOpacity style={s.gotoBtn} onPress={()=>{setTab('map');setTimeout(()=>webViewRef.current?.injectJavaScript(`flyTo(${p.latitude},${p.longitude}); true;`),300);}}>
                <Text style={{fontSize:20}}>📍</Text>
              </TouchableOpacity>
            </TouchableOpacity>
          ))}
        </ScrollView>
      )}

      {/* 추가 모달 */}
      <Modal visible={showAdd} animationType="slide" transparent>
        <KeyboardAvoidingView behavior={Platform.OS==='ios'?'padding':'height'} style={{flex:1}}>
          <View style={s.overlay}>
            <View style={s.sheet}>
              <View style={s.handle}/>
              <Text style={s.mtitle}>사진 추가</Text>
              {pendingImg&&<Image source={{uri:pendingImg}} style={s.preview} resizeMode="cover"/>}
              <Text style={s.label}>제목</Text>
              <TextInput style={s.input} value={title} onChangeText={setTitle} placeholder="제목 (선택)" placeholderTextColor={C.muted}/>
              {!pendingLoc?(
                <>
                  <Text style={s.label}>주소 검색</Text>
                  <View style={{flexDirection:'row',gap:8}}>
                    <TextInput style={[s.input,{flex:1,marginBottom:0}]} value={address} onChangeText={setAddress} placeholder="예: 서울시 강남구" placeholderTextColor={C.muted}/>
                    <TouchableOpacity style={s.pinbtn} onPress={()=>{setShowAdd(false);setPinMode(true);setTab('map');Alert.alert('📌','지도를 탭해서 위치를 선택하세요');}}>
                      <Text style={{fontSize:20}}>📌</Text>
                    </TouchableOpacity>
                  </View>
                </>
              ):(
                <View style={s.locset}>
                  <Text style={s.locsetT}>✅ 위치 설정됨</Text>
                  <TouchableOpacity onPress={()=>setPendingLoc(null)}><Text style={{color:C.accent,fontSize:12}}>변경</Text></TouchableOpacity>
                </View>
              )}
              <Text style={s.label}>메모</Text>
              <TextInput style={[s.input,{height:60,textAlignVertical:'top'}]} value={memo} onChangeText={setMemo} placeholder="메모 (선택)" placeholderTextColor={C.muted} multiline/>
              <View style={s.mbtns}>
                <TouchableOpacity style={[s.mbtn,s.mbtnC]} onPress={()=>{setShowAdd(false);setPendingImg(null);setPendingLoc(null);}}>
                  <Text style={s.mbtnCT}>취소</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[s.mbtn,s.mbtnA]} onPress={savePhoto} disabled={loading}>
                  {loading?<ActivityIndicator color="#fff"/>:<Text style={s.mbtnAT}>저장</Text>}
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </KeyboardAvoidingView>
      </Modal>

      {/* 상세 모달 */}
      <Modal visible={showDetail} animationType="slide" transparent>
        <View style={s.overlay}>
          <View style={s.sheet}>
            <View style={s.handle}/>
            {selected&&<>
              <Image source={{uri:selected.uri}} style={s.detailImg} resizeMode="cover"/>
              <Text style={s.dtitle}>{selected.title}</Text>
              <Text style={s.dinfo}>📍 {selected.address||'주소 없음'}</Text>
              <Text style={s.dinfo}>🕐 {fmt(selected.date)}</Text>
              {selected.memo?<Text style={s.dinfo}>📝 {selected.memo}</Text>:null}
              <View style={s.mbtns}>
                <TouchableOpacity style={[s.mbtn,s.mbtnC]} onPress={()=>setShowDetail(false)}>
                  <Text style={s.mbtnCT}>닫기</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[s.mbtn,{backgroundColor:'#e94560'}]} onPress={()=>deletePhoto(selected.id)}>
                  <Text style={s.mbtnAT}>🗑 삭제</Text>
                </TouchableOpacity>
              </View>
            </>}
          </View>
        </View>
      </Modal>

      {/* 필터 모달 */}
      <Modal visible={showFilter} animationType="slide" transparent>
        <View style={s.overlay}>
          <View style={s.sheet}>
            <View style={s.handle}/>
            <Text style={s.mtitle}>🔍 검색 및 필터</Text>
            <Text style={s.label}>키워드</Text>
            <TextInput style={s.input} value={search} onChangeText={setSearch} placeholder="제목, 주소, 메모" placeholderTextColor={C.muted}/>
            <Text style={s.label}>시작 날짜</Text>
            <TouchableOpacity style={s.datebtn} onPress={()=>setShowStart(true)}>
              <Text style={s.datetxt}>{startDate?startDate.toLocaleDateString('ko-KR'):'날짜 선택'}</Text>
            </TouchableOpacity>
            <Text style={s.label}>종료 날짜</Text>
            <TouchableOpacity style={s.datebtn} onPress={()=>setShowEnd(true)}>
              <Text style={s.datetxt}>{endDate?endDate.toLocaleDateString('ko-KR'):'날짜 선택'}</Text>
            </TouchableOpacity>
            <View style={s.mbtns}>
              <TouchableOpacity style={[s.mbtn,s.mbtnC]} onPress={()=>{setStartDate(null);setEndDate(null);setSearch('');}}>
                <Text style={s.mbtnCT}>초기화</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[s.mbtn,s.mbtnA]} onPress={()=>setShowFilter(false)}>
                <Text style={s.mbtnAT}>적용</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      <DateTimePickerModal isVisible={showStart} mode="date" onConfirm={d=>{setStartDate(d);setShowStart(false);}} onCancel={()=>setShowStart(false)} locale="ko"/>
      <DateTimePickerModal isVisible={showEnd} mode="date" onConfirm={d=>{setEndDate(d);setShowEnd(false);}} onCancel={()=>setShowEnd(false)} locale="ko"/>
    </View>
  );
}

const s = StyleSheet.create({
  container:{flex:1,backgroundColor:C.bg},
  header:{flexDirection:'row',justifyContent:'space-between',alignItems:'center',backgroundColor:C.surface,paddingHorizontal:16,paddingTop:Platform.OS==='android'?44:52,paddingBottom:12,borderBottomWidth:1,borderBottomColor:C.border},
  htitle:{color:C.text,fontSize:20,fontWeight:'700'},
  hsub:{color:C.muted,fontSize:12,marginTop:2},
  hbtns:{flexDirection:'row',alignItems:'center',gap:8},
  ibtn:{width:38,height:38,borderRadius:10,backgroundColor:C.card,alignItems:'center',justifyContent:'center',borderWidth:1,borderColor:C.border},
  ibtnOn:{borderColor:C.accent,backgroundColor:'#0f3460'},
  ibtxt:{fontSize:18},
  badge:{position:'absolute',top:-4,right:-4,width:16,height:16,borderRadius:8,backgroundColor:C.accent,alignItems:'center',justifyContent:'center'},
  badgeTxt:{color:'#fff',fontSize:10,fontWeight:'700'},
  addbtn:{backgroundColor:C.accent,paddingHorizontal:14,paddingVertical:8,borderRadius:10,minWidth:60,alignItems:'center'},
  addtxt:{color:'#fff',fontWeight:'700',fontSize:14},
  tabs:{flexDirection:'row',backgroundColor:C.surface,borderBottomWidth:1,borderBottomColor:C.border},
  tab:{flex:1,paddingVertical:10,alignItems:'center'},
  tabOn:{borderBottomWidth:2,borderBottomColor:C.accent},
  tabtxt:{color:C.muted,fontSize:14},
  tabtxtOn:{color:C.accent,fontWeight:'700'},
  pinBanner:{backgroundColor:C.accent,paddingVertical:8,paddingHorizontal:16,flexDirection:'row',justifyContent:'space-between',alignItems:'center'},
  pinTxt:{color:'#fff',fontWeight:'600',fontSize:13},
  pinCancel:{color:'rgba(255,255,255,0.8)',fontSize:13,textDecorationLine:'underline'},
  map:{flex:1},
  list:{flex:1,backgroundColor:C.bg,paddingTop:8,paddingHorizontal:12},
  empty:{alignItems:'center',paddingTop:80},
  emptyT:{color:C.text,fontSize:18,fontWeight:'700',marginBottom:8},
  emptyD:{color:C.muted,fontSize:14},
  item:{flexDirection:'row',backgroundColor:C.card,borderRadius:12,marginBottom:10,overflow:'hidden',borderWidth:1,borderColor:C.border},
  thumb:{width:80,height:80},
  info:{flex:1,padding:10,justifyContent:'center'},
  ititle:{color:C.text,fontSize:14,fontWeight:'600',marginBottom:3},
  iaddr:{color:C.muted,fontSize:11,marginBottom:3,lineHeight:16},
  idate:{color:'#ff6b81',fontSize:11},
  gotoBtn:{padding:10,justifyContent:'center',alignItems:'center',width:44},
  overlay:{flex:1,backgroundColor:'rgba(0,0,0,0.7)',justifyContent:'flex-end'},
  sheet:{backgroundColor:C.surface,borderTopLeftRadius:20,borderTopRightRadius:20,padding:20,paddingBottom:Platform.OS==='ios'?34:20,maxHeight:height*0.9},
  handle:{width:36,height:4,backgroundColor:C.border,borderRadius:2,alignSelf:'center',marginBottom:16},
  mtitle:{color:C.text,fontSize:18,fontWeight:'700',marginBottom:16},
  label:{color:C.muted,fontSize:12,marginBottom:6,marginTop:8},
  input:{backgroundColor:C.card,borderRadius:10,padding:12,color:C.text,fontSize:14,borderWidth:1,borderColor:C.border,marginBottom:4},
  pinbtn:{width:44,height:44,backgroundColor:C.card,borderRadius:10,alignItems:'center',justifyContent:'center',borderWidth:1,borderColor:C.border},
  locset:{backgroundColor:'#0f3460',borderRadius:10,padding:10,flexDirection:'row',justifyContent:'space-between',alignItems:'center',marginBottom:4},
  locsetT:{color:C.success,fontSize:12,flex:1},
  datebtn:{backgroundColor:C.card,borderRadius:10,padding:12,borderWidth:1,borderColor:C.border,marginBottom:4},
  datetxt:{color:C.text,fontSize:14},
  mbtns:{flexDirection:'row',gap:10,marginTop:16},
  mbtn:{flex:1,padding:14,borderRadius:10,alignItems:'center'},
  mbtnC:{backgroundColor:C.card,borderWidth:1,borderColor:C.border},
  mbtnCT:{color:C.muted,fontWeight:'600'},
  mbtnA:{backgroundColor:C.accent},
  mbtnAT:{color:'#fff',fontWeight:'700'},
  preview:{width:'100%',height:160,borderRadius:12,marginBottom:12},
  detailImg:{width:'100%',height:200,borderRadius:12,marginBottom:12},
  dtitle:{color:C.text,fontSize:18,fontWeight:'700',marginBottom:8},
  dinfo:{color:C.muted,fontSize:13,marginBottom:6,lineHeight:18},
});
