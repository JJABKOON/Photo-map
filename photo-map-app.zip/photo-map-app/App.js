import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Modal,
  TextInput,
  ScrollView,
  Image,
  Alert,
  Platform,
  Dimensions,
  ActivityIndicator,
  KeyboardAvoidingView,
} from 'react-native';
import MapView, { Marker, Callout } from 'react-native-maps';
import * as ImagePicker from 'expo-image-picker';
import * as Location from 'expo-location';
import * as MediaLibrary from 'expo-media-library';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { StatusBar } from 'expo-status-bar';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import DateTimePickerModal from 'react-native-modal-datetime-picker';

const { width, height } = Dimensions.get('window');
const STORAGE_KEY = '@photo_map_photos';

// 색상 팔레트
const COLORS = {
  bg: '#0f0f1a',
  surface: '#1a1a2e',
  card: '#16213e',
  accent: '#e94560',
  accentSoft: '#ff6b81',
  accentBlue: '#0f3460',
  text: '#e8e8f0',
  textMuted: '#8888aa',
  border: '#2a2a4a',
  success: '#4ecca3',
  warning: '#ffd460',
};

export default function App() {
  const mapRef = useRef(null);
  const [photos, setPhotos] = useState([]);
  const [filteredPhotos, setFilteredPhotos] = useState([]);
  const [selectedPhoto, setSelectedPhoto] = useState(null);
  const [showPhotoModal, setShowPhotoModal] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showFilterModal, setShowFilterModal] = useState(false);
  const [showDetailModal, setShowDetailModal] = useState(false);
  const [pinMode, setPinMode] = useState(false);
  const [pendingLocation, setPendingLocation] = useState(null);
  const [pendingImage, setPendingImage] = useState(null);
  const [photoTitle, setPhotoTitle] = useState('');
  const [photoAddress, setPhotoAddress] = useState('');
  const [photoMemo, setPhotoMemo] = useState('');
  const [filterStartDate, setFilterStartDate] = useState(null);
  const [filterEndDate, setFilterEndDate] = useState(null);
  const [showStartPicker, setShowStartPicker] = useState(false);
  const [showEndPicker, setShowEndPicker] = useState(false);
  const [searchText, setSearchText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [currentLocation, setCurrentLocation] = useState(null);
  const [activeTab, setActiveTab] = useState('map'); // 'map' | 'list'

  const initialRegion = {
    latitude: 37.5665,
    longitude: 126.9780,
    latitudeDelta: 0.5,
    longitudeDelta: 0.5,
  };

  // 초기 로드
  useEffect(() => {
    loadPhotos();
    requestPermissions();
  }, []);

  // 필터링
  useEffect(() => {
    applyFilters();
  }, [photos, filterStartDate, filterEndDate, searchText]);

  const requestPermissions = async () => {
    await Location.requestForegroundPermissionsAsync();
    await MediaLibrary.requestPermissionsAsync();
    await ImagePicker.requestMediaLibraryPermissionsAsync();

    const loc = await Location.getCurrentPositionAsync({});
    if (loc) {
      setCurrentLocation({
        latitude: loc.coords.latitude,
        longitude: loc.coords.longitude,
        latitudeDelta: 0.1,
        longitudeDelta: 0.1,
      });
    }
  };

  const loadPhotos = async () => {
    try {
      const data = await AsyncStorage.getItem(STORAGE_KEY);
      if (data) {
        setPhotos(JSON.parse(data));
      }
    } catch (e) {
      console.error(e);
    }
  };

  const savePhotos = async (newPhotos) => {
    try {
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(newPhotos));
    } catch (e) {
      console.error(e);
    }
  };

  const applyFilters = () => {
    let result = [...photos];
    if (filterStartDate) {
      result = result.filter(p => new Date(p.date) >= filterStartDate);
    }
    if (filterEndDate) {
      const end = new Date(filterEndDate);
      end.setHours(23, 59, 59);
      result = result.filter(p => new Date(p.date) <= end);
    }
    if (searchText.trim()) {
      const q = searchText.toLowerCase();
      result = result.filter(p =>
        p.title?.toLowerCase().includes(q) ||
        p.address?.toLowerCase().includes(q) ||
        p.memo?.toLowerCase().includes(q)
      );
    }
    setFilteredPhotos(result);
  };

  // 사진 선택
  const pickImage = async () => {
    setIsLoading(true);
    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: false,
        quality: 0.7,
        exif: true,
      });

      if (!result.canceled && result.assets[0]) {
        const asset = result.assets[0];
        const exif = asset.exif;

        // EXIF GPS 확인
        const lat = exif?.GPSLatitude || exif?.['GPS Latitude'];
        const lng = exif?.GPSLongitude || exif?.['GPS Longitude'];

        if (lat && lng) {
          // GPS 정보 있음
          setPendingImage(asset.uri);
          setPendingLocation({ latitude: parseFloat(lat), longitude: parseFloat(lng) });
          setPhotoTitle('');
          setPhotoAddress('');
          setPhotoMemo('');
          setShowAddModal(true);
        } else {
          // GPS 없음 - 위치 선택 안내
          setPendingImage(asset.uri);
          Alert.alert(
            '위치 정보 없음',
            '이 사진에 위치 정보가 없습니다. 어떻게 위치를 추가하시겠어요?',
            [
              {
                text: '지도에서 핀 꽂기',
                onPress: () => {
                  setShowAddModal(false);
                  setPinMode(true);
                  Alert.alert('📍 핀 꽂기 모드', '지도에서 원하는 위치를 탭하세요');
                },
              },
              {
                text: '주소로 검색',
                onPress: () => {
                  setPendingLocation(null);
                  setPhotoTitle('');
                  setPhotoAddress('');
                  setPhotoMemo('');
                  setShowAddModal(true);
                },
              },
              { text: '취소', style: 'cancel', onPress: () => setPendingImage(null) },
            ]
          );
        }
      }
    } catch (e) {
      Alert.alert('오류', '사진을 불러오는데 실패했습니다.');
    }
    setIsLoading(false);
  };

  // 지도 탭으로 핀 꽂기
  const handleMapPress = (e) => {
    if (pinMode) {
      const coord = e.nativeEvent.coordinate;
      setPendingLocation(coord);
      setPinMode(false);
      setPhotoTitle('');
      setPhotoAddress('');
      setPhotoMemo('');
      setShowAddModal(true);
    }
  };

  // 주소 → 좌표 변환 (Nominatim)
  const geocodeAddress = async (address) => {
    try {
      const res = await fetch(
        `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(address)}&format=json&limit=1`,
        { headers: { 'Accept-Language': 'ko' } }
      );
      const data = await res.json();
      if (data.length > 0) {
        return {
          latitude: parseFloat(data[0].lat),
          longitude: parseFloat(data[0].lon),
          displayName: data[0].display_name,
        };
      }
    } catch (e) {}
    return null;
  };

  // 좌표 → 주소 변환
  const reverseGeocode = async (lat, lng) => {
    try {
      const res = await fetch(
        `https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lng}&format=json`,
        { headers: { 'Accept-Language': 'ko' } }
      );
      const data = await res.json();
      return data.display_name || '';
    } catch (e) {
      return '';
    }
  };

  // 사진 저장
  const savePhoto = async () => {
    let location = pendingLocation;

    if (!location && photoAddress.trim()) {
      setIsLoading(true);
      const geo = await geocodeAddress(photoAddress);
      setIsLoading(false);
      if (geo) {
        location = { latitude: geo.latitude, longitude: geo.longitude };
      } else {
        Alert.alert('주소 오류', '입력한 주소를 찾을 수 없습니다. 다시 확인해주세요.');
        return;
      }
    }

    if (!location) {
      Alert.alert('위치 필요', '위치를 설정해주세요. 지도에서 핀을 꽂거나 주소를 입력하세요.');
      return;
    }

    if (!pendingImage) {
      Alert.alert('사진 필요', '사진을 선택해주세요.');
      return;
    }

    // 주소 없으면 역지오코딩
    let addr = photoAddress;
    if (!addr.trim()) {
      addr = await reverseGeocode(location.latitude, location.longitude);
    }

    const newPhoto = {
      id: Date.now().toString(),
      uri: pendingImage,
      latitude: location.latitude,
      longitude: location.longitude,
      title: photoTitle.trim() || `사진 ${photos.length + 1}`,
      address: addr,
      memo: photoMemo,
      date: new Date().toISOString(),
    };

    const updated = [newPhoto, ...photos];
    setPhotos(updated);
    await savePhotos(updated);

    // 초기화
    setShowAddModal(false);
    setPendingImage(null);
    setPendingLocation(null);
    setPhotoTitle('');
    setPhotoAddress('');
    setPhotoMemo('');

    // 지도 이동
    mapRef.current?.animateToRegion({
      latitude: location.latitude,
      longitude: location.longitude,
      latitudeDelta: 0.05,
      longitudeDelta: 0.05,
    }, 800);
  };

  const deletePhoto = (id) => {
    Alert.alert('삭제', '이 사진을 삭제하시겠어요?', [
      {
        text: '삭제',
        style: 'destructive',
        onPress: async () => {
          const updated = photos.filter(p => p.id !== id);
          setPhotos(updated);
          await savePhotos(updated);
          setShowDetailModal(false);
        },
      },
      { text: '취소', style: 'cancel' },
    ]);
  };

  const formatDate = (iso) => {
    const d = new Date(iso);
    return `${d.getFullYear()}.${String(d.getMonth()+1).padStart(2,'0')}.${String(d.getDate()).padStart(2,'0')} ${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`;
  };

  const clearFilters = () => {
    setFilterStartDate(null);
    setFilterEndDate(null);
    setSearchText('');
  };

  const activeFilterCount = (filterStartDate ? 1 : 0) + (filterEndDate ? 1 : 0) + (searchText ? 1 : 0);

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <StatusBar style="light" />
      <View style={styles.container}>

        {/* 헤더 */}
        <View style={styles.header}>
          <View>
            <Text style={styles.headerTitle}>📍 포토맵</Text>
            <Text style={styles.headerSub}>{filteredPhotos.length}개의 사진</Text>
          </View>
          <View style={styles.headerActions}>
            <TouchableOpacity
              style={[styles.iconBtn, activeFilterCount > 0 && styles.iconBtnActive]}
              onPress={() => setShowFilterModal(true)}
            >
              <Text style={styles.iconBtnText}>🔍</Text>
              {activeFilterCount > 0 && (
                <View style={styles.badge}>
                  <Text style={styles.badgeText}>{activeFilterCount}</Text>
                </View>
              )}
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.iconBtn, pinMode && styles.iconBtnActive]}
              onPress={() => {
                setPendingImage(null);
                setPinMode(!pinMode);
                if (!pinMode) Alert.alert('📍 핀 꽂기 모드', '사진 없이 장소만 핀을 꽂으려면 지도를 탭하세요');
              }}
            >
              <Text style={styles.iconBtnText}>📌</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.addBtn} onPress={pickImage} disabled={isLoading}>
              {isLoading ? (
                <ActivityIndicator color="#fff" size="small" />
              ) : (
                <Text style={styles.addBtnText}>+ 사진</Text>
              )}
            </TouchableOpacity>
          </View>
        </View>

        {/* 탭 */}
        <View style={styles.tabBar}>
          <TouchableOpacity
            style={[styles.tab, activeTab === 'map' && styles.tabActive]}
            onPress={() => setActiveTab('map')}
          >
            <Text style={[styles.tabText, activeTab === 'map' && styles.tabTextActive]}>🗺 지도</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.tab, activeTab === 'list' && styles.tabActive]}
            onPress={() => setActiveTab('list')}
          >
            <Text style={[styles.tabText, activeTab === 'list' && styles.tabTextActive]}>📋 목록</Text>
          </TouchableOpacity>
        </View>

        {/* 핀모드 안내 */}
        {pinMode && (
          <View style={styles.pinModeBanner}>
            <Text style={styles.pinModeTxt}>📍 지도를 탭하여 위치를 선택하세요</Text>
            <TouchableOpacity onPress={() => setPinMode(false)}>
              <Text style={styles.pinModeCancel}>취소</Text>
            </TouchableOpacity>
          </View>
        )}

        {/* 지도 탭 */}
        {activeTab === 'map' && (
          <MapView
            ref={mapRef}
            style={styles.map}
            initialRegion={currentLocation || initialRegion}
            onPress={handleMapPress}
            customMapStyle={darkMapStyle}
            showsUserLocation
            showsMyLocationButton
          >
            {filteredPhotos.map((photo) => (
              <Marker
                key={photo.id}
                coordinate={{ latitude: photo.latitude, longitude: photo.longitude }}
                onPress={() => {
                  setSelectedPhoto(photo);
                  setShowDetailModal(true);
                }}
              >
                <View style={styles.markerContainer}>
                  <Image source={{ uri: photo.uri }} style={styles.markerImage} />
                  <View style={styles.markerPin} />
                </View>
              </Marker>
            ))}
          </MapView>
        )}

        {/* 목록 탭 */}
        {activeTab === 'list' && (
          <ScrollView style={styles.listContainer} contentContainerStyle={{ paddingBottom: 20 }}>
            {filteredPhotos.length === 0 ? (
              <View style={styles.emptyState}>
                <Text style={styles.emptyIcon}>🏞</Text>
                <Text style={styles.emptyTitle}>사진이 없습니다</Text>
                <Text style={styles.emptyDesc}>+ 사진 버튼으로 첫 사진을 추가해보세요</Text>
              </View>
            ) : (
              filteredPhotos.map((photo) => (
                <TouchableOpacity
                  key={photo.id}
                  style={styles.listItem}
                  onPress={() => {
                    setSelectedPhoto(photo);
                    setShowDetailModal(true);
                  }}
                >
                  <Image source={{ uri: photo.uri }} style={styles.listThumb} />
                  <View style={styles.listInfo}>
                    <Text style={styles.listTitle} numberOfLines={1}>{photo.title}</Text>
                    <Text style={styles.listAddr} numberOfLines={2}>{photo.address || '주소 없음'}</Text>
                    <Text style={styles.listDate}>{formatDate(photo.date)}</Text>
                  </View>
                  <TouchableOpacity
                    style={styles.listMapBtn}
                    onPress={() => {
                      setActiveTab('map');
                      mapRef.current?.animateToRegion({
                        latitude: photo.latitude,
                        longitude: photo.longitude,
                        latitudeDelta: 0.02,
                        longitudeDelta: 0.02,
                      }, 600);
                    }}
                  >
                    <Text style={{ fontSize: 20 }}>📍</Text>
                  </TouchableOpacity>
                </TouchableOpacity>
              ))
            )}
          </ScrollView>
        )}

        {/* ─── 사진 추가 모달 ─── */}
        <Modal visible={showAddModal} animationType="slide" transparent>
          <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1 }}>
            <View style={styles.modalOverlay}>
              <View style={styles.modalSheet}>
                <View style={styles.modalHandle} />
                <Text style={styles.modalTitle}>사진 추가</Text>

                {pendingImage && (
                  <Image source={{ uri: pendingImage }} style={styles.previewImage} resizeMode="cover" />
                )}

                <Text style={styles.inputLabel}>제목</Text>
                <TextInput
                  style={styles.input}
                  value={photoTitle}
                  onChangeText={setPhotoTitle}
                  placeholder="사진 제목 (선택)"
                  placeholderTextColor={COLORS.textMuted}
                />

                {!pendingLocation ? (
                  <>
                    <Text style={styles.inputLabel}>주소 검색</Text>
                    <View style={styles.addressRow}>
                      <TextInput
                        style={[styles.input, { flex: 1, marginBottom: 0 }]}
                        value={photoAddress}
                        onChangeText={setPhotoAddress}
                        placeholder="예: 서울시 강남구 역삼동"
                        placeholderTextColor={COLORS.textMuted}
                        returnKeyType="search"
                      />
                      <TouchableOpacity
                        style={styles.pinBtn}
                        onPress={() => {
                          setShowAddModal(false);
                          setPinMode(true);
                          Alert.alert('📍 핀 꽂기', '지도에서 위치를 탭하세요');
                        }}
                      >
                        <Text style={{ fontSize: 20 }}>📌</Text>
                      </TouchableOpacity>
                    </View>
                  </>
                ) : (
                  <View style={styles.locationSet}>
                    <Text style={styles.locationSetText}>
                      ✅ 위치 설정됨 ({pendingLocation.latitude.toFixed(4)}, {pendingLocation.longitude.toFixed(4)})
                    </Text>
                    <TouchableOpacity onPress={() => setPendingLocation(null)}>
                      <Text style={{ color: COLORS.accent, fontSize: 12 }}>변경</Text>
                    </TouchableOpacity>
                  </View>
                )}

                <Text style={styles.inputLabel}>메모</Text>
                <TextInput
                  style={[styles.input, { height: 70, textAlignVertical: 'top' }]}
                  value={photoMemo}
                  onChangeText={setPhotoMemo}
                  placeholder="메모 (선택)"
                  placeholderTextColor={COLORS.textMuted}
                  multiline
                />

                <View style={styles.modalBtns}>
                  <TouchableOpacity
                    style={[styles.modalBtn, styles.modalBtnCancel]}
                    onPress={() => {
                      setShowAddModal(false);
                      setPendingImage(null);
                      setPendingLocation(null);
                    }}
                  >
                    <Text style={styles.modalBtnCancelText}>취소</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={[styles.modalBtn, styles.modalBtnConfirm]}
                    onPress={savePhoto}
                    disabled={isLoading}
                  >
                    {isLoading ? (
                      <ActivityIndicator color="#fff" />
                    ) : (
                      <Text style={styles.modalBtnConfirmText}>저장</Text>
                    )}
                  </TouchableOpacity>
                </View>
              </View>
            </View>
          </KeyboardAvoidingView>
        </Modal>

        {/* ─── 사진 상세 모달 ─── */}
        <Modal visible={showDetailModal} animationType="slide" transparent>
          <View style={styles.modalOverlay}>
            <View style={styles.modalSheet}>
              <View style={styles.modalHandle} />
              {selectedPhoto && (
                <>
                  <Image source={{ uri: selectedPhoto.uri }} style={styles.detailImage} resizeMode="cover" />
                  <View style={styles.detailBody}>
                    <Text style={styles.detailTitle}>{selectedPhoto.title}</Text>
                    <View style={styles.detailRow}>
                      <Text style={styles.detailIcon}>📍</Text>
                      <Text style={styles.detailText} numberOfLines={2}>{selectedPhoto.address || '주소 없음'}</Text>
                    </View>
                    <View style={styles.detailRow}>
                      <Text style={styles.detailIcon}>🕐</Text>
                      <Text style={styles.detailText}>{formatDate(selectedPhoto.date)}</Text>
                    </View>
                    {selectedPhoto.memo ? (
                      <View style={styles.detailRow}>
                        <Text style={styles.detailIcon}>📝</Text>
                        <Text style={styles.detailText}>{selectedPhoto.memo}</Text>
                      </View>
                    ) : null}
                  </View>
                  <View style={styles.modalBtns}>
                    <TouchableOpacity
                      style={[styles.modalBtn, styles.modalBtnCancel]}
                      onPress={() => setShowDetailModal(false)}
                    >
                      <Text style={styles.modalBtnCancelText}>닫기</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                      style={[styles.modalBtn, { backgroundColor: '#e94560' }]}
                      onPress={() => deletePhoto(selectedPhoto.id)}
                    >
                      <Text style={styles.modalBtnConfirmText}>🗑 삭제</Text>
                    </TouchableOpacity>
                  </View>
                </>
              )}
            </View>
          </View>
        </Modal>

        {/* ─── 필터 모달 ─── */}
        <Modal visible={showFilterModal} animationType="slide" transparent>
          <View style={styles.modalOverlay}>
            <View style={styles.modalSheet}>
              <View style={styles.modalHandle} />
              <Text style={styles.modalTitle}>🔍 검색 및 필터</Text>

              <Text style={styles.inputLabel}>키워드 검색</Text>
              <TextInput
                style={styles.input}
                value={searchText}
                onChangeText={setSearchText}
                placeholder="제목, 주소, 메모 검색"
                placeholderTextColor={COLORS.textMuted}
              />

              <Text style={styles.inputLabel}>시작 날짜</Text>
              <TouchableOpacity
                style={styles.dateBtn}
                onPress={() => setShowStartPicker(true)}
              >
                <Text style={styles.dateBtnText}>
                  {filterStartDate ? filterStartDate.toLocaleDateString('ko-KR') : '날짜 선택'}
                </Text>
              </TouchableOpacity>

              <Text style={styles.inputLabel}>종료 날짜</Text>
              <TouchableOpacity
                style={styles.dateBtn}
                onPress={() => setShowEndPicker(true)}
              >
                <Text style={styles.dateBtnText}>
                  {filterEndDate ? filterEndDate.toLocaleDateString('ko-KR') : '날짜 선택'}
                </Text>
              </TouchableOpacity>

              <View style={styles.modalBtns}>
                <TouchableOpacity
                  style={[styles.modalBtn, styles.modalBtnCancel]}
                  onPress={clearFilters}
                >
                  <Text style={styles.modalBtnCancelText}>초기화</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.modalBtn, styles.modalBtnConfirm]}
                  onPress={() => setShowFilterModal(false)}
                >
                  <Text style={styles.modalBtnConfirmText}>적용</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </Modal>

        {/* 날짜 선택기 */}
        <DateTimePickerModal
          isVisible={showStartPicker}
          mode="date"
          onConfirm={(date) => { setFilterStartDate(date); setShowStartPicker(false); }}
          onCancel={() => setShowStartPicker(false)}
          locale="ko"
        />
        <DateTimePickerModal
          isVisible={showEndPicker}
          mode="date"
          onConfirm={(date) => { setFilterEndDate(date); setShowEndPicker(false); }}
          onCancel={() => setShowEndPicker(false)}
          locale="ko"
        />
      </View>
    </GestureHandlerRootView>
  );
}

// 다크 맵 스타일
const darkMapStyle = [
  { elementType: 'geometry', stylers: [{ color: '#1a1a2e' }] },
  { elementType: 'labels.text.stroke', stylers: [{ color: '#0f0f1a' }] },
  { elementType: 'labels.text.fill', stylers: [{ color: '#8888aa' }] },
  { featureType: 'road', elementType: 'geometry', stylers: [{ color: '#16213e' }] },
  { featureType: 'road', elementType: 'geometry.stroke', stylers: [{ color: '#0f3460' }] },
  { featureType: 'water', elementType: 'geometry', stylers: [{ color: '#0f3460' }] },
  { featureType: 'poi', elementType: 'geometry', stylers: [{ color: '#16213e' }] },
  { featureType: 'transit', elementType: 'geometry', stylers: [{ color: '#16213e' }] },
];

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.bg },

  // 헤더
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    backgroundColor: COLORS.surface, paddingHorizontal: 16,
    paddingTop: Platform.OS === 'android' ? 44 : 52, paddingBottom: 12,
    borderBottomWidth: 1, borderBottomColor: COLORS.border,
  },
  headerTitle: { color: COLORS.text, fontSize: 20, fontWeight: '700' },
  headerSub: { color: COLORS.textMuted, fontSize: 12, marginTop: 2 },
  headerActions: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  iconBtn: {
    width: 38, height: 38, borderRadius: 10, backgroundColor: COLORS.card,
    alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: COLORS.border,
  },
  iconBtnActive: { borderColor: COLORS.accent, backgroundColor: COLORS.accentBlue },
  iconBtnText: { fontSize: 18 },
  badge: {
    position: 'absolute', top: -4, right: -4, width: 16, height: 16,
    borderRadius: 8, backgroundColor: COLORS.accent, alignItems: 'center', justifyContent: 'center',
  },
  badgeText: { color: '#fff', fontSize: 10, fontWeight: '700' },
  addBtn: {
    backgroundColor: COLORS.accent, paddingHorizontal: 14, paddingVertical: 8,
    borderRadius: 10, minWidth: 60, alignItems: 'center',
  },
  addBtnText: { color: '#fff', fontWeight: '700', fontSize: 14 },

  // 탭
  tabBar: {
    flexDirection: 'row', backgroundColor: COLORS.surface,
    borderBottomWidth: 1, borderBottomColor: COLORS.border,
  },
  tab: { flex: 1, paddingVertical: 10, alignItems: 'center' },
  tabActive: { borderBottomWidth: 2, borderBottomColor: COLORS.accent },
  tabText: { color: COLORS.textMuted, fontSize: 14 },
  tabTextActive: { color: COLORS.accent, fontWeight: '700' },

  // 핀 모드 배너
  pinModeBanner: {
    backgroundColor: COLORS.accent, paddingVertical: 8, paddingHorizontal: 16,
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
  },
  pinModeTxt: { color: '#fff', fontWeight: '600', fontSize: 13 },
  pinModeCancel: { color: 'rgba(255,255,255,0.8)', fontSize: 13, textDecorationLine: 'underline' },

  // 지도
  map: { flex: 1 },

  // 마커
  markerContainer: { alignItems: 'center' },
  markerImage: { width: 48, height: 48, borderRadius: 8, borderWidth: 2, borderColor: '#fff' },
  markerPin: {
    width: 2, height: 8, backgroundColor: COLORS.accent,
    marginTop: -1, borderBottomLeftRadius: 2, borderBottomRightRadius: 2,
  },

  // 목록
  listContainer: { flex: 1, backgroundColor: COLORS.bg, paddingTop: 8, paddingHorizontal: 12 },
  listItem: {
    flexDirection: 'row', backgroundColor: COLORS.card, borderRadius: 12,
    marginBottom: 10, overflow: 'hidden', borderWidth: 1, borderColor: COLORS.border,
  },
  listThumb: { width: 80, height: 80 },
  listInfo: { flex: 1, padding: 10, justifyContent: 'center' },
  listTitle: { color: COLORS.text, fontSize: 14, fontWeight: '600', marginBottom: 3 },
  listAddr: { color: COLORS.textMuted, fontSize: 11, marginBottom: 3, lineHeight: 16 },
  listDate: { color: COLORS.accentSoft, fontSize: 11 },
  listMapBtn: { padding: 10, justifyContent: 'center', alignItems: 'center', width: 44 },

  // 빈 상태
  emptyState: { alignItems: 'center', paddingTop: 80 },
  emptyIcon: { fontSize: 60, marginBottom: 16 },
  emptyTitle: { color: COLORS.text, fontSize: 18, fontWeight: '700', marginBottom: 8 },
  emptyDesc: { color: COLORS.textMuted, fontSize: 14 },

  // 모달 공통
  modalOverlay: {
    flex: 1, backgroundColor: 'rgba(0,0,0,0.7)',
    justifyContent: 'flex-end',
  },
  modalSheet: {
    backgroundColor: COLORS.surface, borderTopLeftRadius: 20, borderTopRightRadius: 20,
    padding: 20, paddingBottom: Platform.OS === 'ios' ? 34 : 20,
    maxHeight: height * 0.9,
  },
  modalHandle: {
    width: 36, height: 4, backgroundColor: COLORS.border,
    borderRadius: 2, alignSelf: 'center', marginBottom: 16,
  },
  modalTitle: { color: COLORS.text, fontSize: 18, fontWeight: '700', marginBottom: 16 },

  // 입력
  inputLabel: { color: COLORS.textMuted, fontSize: 12, marginBottom: 6, marginTop: 8 },
  input: {
    backgroundColor: COLORS.card, borderRadius: 10, padding: 12,
    color: COLORS.text, fontSize: 14, borderWidth: 1, borderColor: COLORS.border,
    marginBottom: 4,
  },
  addressRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 4 },
  pinBtn: {
    width: 44, height: 44, backgroundColor: COLORS.card, borderRadius: 10,
    alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: COLORS.border,
  },
  locationSet: {
    backgroundColor: COLORS.accentBlue, borderRadius: 10, padding: 10,
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4,
  },
  locationSetText: { color: COLORS.success, fontSize: 12, flex: 1 },

  // 날짜
  dateBtn: {
    backgroundColor: COLORS.card, borderRadius: 10, padding: 12,
    borderWidth: 1, borderColor: COLORS.border, marginBottom: 4,
  },
  dateBtnText: { color: COLORS.text, fontSize: 14 },

  // 모달 버튼
  modalBtns: { flexDirection: 'row', gap: 10, marginTop: 16 },
  modalBtn: { flex: 1, padding: 14, borderRadius: 10, alignItems: 'center' },
  modalBtnCancel: { backgroundColor: COLORS.card, borderWidth: 1, borderColor: COLORS.border },
  modalBtnCancelText: { color: COLORS.textMuted, fontWeight: '600' },
  modalBtnConfirm: { backgroundColor: COLORS.accent },
  modalBtnConfirmText: { color: '#fff', fontWeight: '700' },

  // 미리보기
  previewImage: {
    width: '100%', height: 180, borderRadius: 12, marginBottom: 12,
  },

  // 상세
  detailImage: { width: '100%', height: 220, borderRadius: 12, marginBottom: 16 },
  detailBody: { gap: 8, marginBottom: 8 },
  detailTitle: { color: COLORS.text, fontSize: 20, fontWeight: '700', marginBottom: 4 },
  detailRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 8 },
  detailIcon: { fontSize: 14, marginTop: 1 },
  detailText: { color: COLORS.textMuted, fontSize: 13, flex: 1, lineHeight: 18 },
});
