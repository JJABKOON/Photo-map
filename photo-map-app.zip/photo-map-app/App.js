import React, { useState, useEffect, useRef } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, Modal,
  TextInput, ScrollView, Image, Alert, Platform,
  Dimensions, ActivityIndicator, KeyboardAvoidingView,
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import * as Location from 'expo-location';
import * as MediaLibrary from 'expo-media-library';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { StatusBar } from 'expo-status-bar';
import DateTimePickerModal from 'react-native-modal-datetime-picker';
import { WebView } from 'react-native-webview';

const { width, height } = Dimensions.get('window');
const STORAGE_KEY = '@photo_map_v3';

const C = {
  bg: '#f5f5f0', surface: '#ffffff', card: '#fafaf8',
  accent: '#2d6a4f', accentLight: '#40916c', accentSoft: '#d8f3dc',
  text: '#1b1b1b', muted: '#888880', border: '#e0e0d8',
  red: '#e63946', dark: '#2d2d2d',
};

// EXIF GPS 변환 함수
function parseExifGPS(exif) {
  if (!exif) return null;
  try {
    let lat = exif.GPSLatitude ?? exif['GPS Latitude'] ?? exif.gpsLatitude;
    let lng = exif.GPSLongitude ?? exif['GPS Longitude'] ?? exif.gpsLongitude;
    let latRef = exif.GPSLatitudeRef ?? exif['GPS Latitude Ref'] ?? 'N';
    let lngRef = exif.GPSLongitudeRef ?? exif['GPS Longitude Ref'] ?? 'E';

    if (lat == null || lng == null) return null;

    // 배열 형식 [도, 분, 초] 처리
    if (Array.isArray(lat)) {
      lat = lat[0] + lat[1] / 60 + lat[2] / 3600;
    }
    if (Array.isArray(lng)) {
      lng = lng[0] + lng[1] / 60 + lng[2] / 3600;
    }

    // 분수 형식 처리 (일부 기기)
    if (typeof lat === 'string' && lat.includes('/')) {
      const parts = lat.split(',').map(p => {
        const [n, d] = p.trim().split('/');
        return parseFloat(n) / parseFloat(d);
      });
      lat = parts[0] + parts[1] / 60 + parts[2] / 3600;
    }
    if (typeof lng === 'string' && lng.includes('/')) {
      const parts = lng.split(',').map(p => {
        const [n, d] = p.trim().split('/');
        return parseFloat(n) / parseFloat(d);
      });
      lng = parts[0] + parts[1] / 60 + parts[2] / 3600;
    }

    lat = parseFloat(lat);
    lng = parseFloat(lng);

    if (isNaN(lat) || isNaN(lng)) return null;
    if (latRef === 'S') lat = -lat;
    if (lngRef === 'W') lng = -lng;
    if (lat === 0 && lng === 0) return null;

    return { latitude: lat, longitude: lng };
  } catch (e) {
    return null;
  }
}

export default function App() {
  const webViewRef = useRef(null);
  const [photos, setPhotos] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [tab, setTab] = useState('map');
  const [showAdd, setShowAdd] = useState(false);
  const [showDetail, setShowDetail] = useState(false);
  const [showFilter, setShowFilter] = useState(false);
  const [selected, setSelected] = useState(null);
  const [pendingImg, setPendingImg] = useState(null);
  const [pendingLoc, setPendingLoc] = useState(null);
  const [pinMode, setPinMode] = useState(false);
  const [title, setTitle] = useState('');
  const [address, setAddress] = useState('');
  const [memo, setMemo] = useState('');
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);
  const [showStart, setShowStart] = useState(false);
  const [showEnd, setShowEnd] = useState(false);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(false);
  const [mapReady, setMapReady] = useState(false);
  const [currentLat, setCurrentLat] = useState(37.5665);
  const [currentLng, setCurrentLng] = useState(126.9780);
  const [gpsDetected, setGpsDetected] = useState(false);

  useEffect(() => { init(); }, []);
  useEffect(() => { applyFilter(); }, [photos, startDate, endDate, search]);
  useEffect(() => { if (mapReady) updateMapMarkers(); }, [filtered, mapReady]);

  const init = async () => {
    const data = await AsyncStorage.getItem(STORAGE_KEY);
    if (data) setPhotos(JSON.parse(data));
    const { status } = await Location.requestForegroundPermissionsAsync();
    if (status === 'granted') {
      const loc = await Location.getCurrentPositionAsync({});
      setCurrentLat(loc.coords.latitude);
      setCurrentLng(loc.coords.longitude);
    }
    await ImagePicker.requestMediaLibraryPermissionsAsync();
    await MediaLibrary.requestPermissionsAsync();
  };

  const save = async (list) => {
    setPhotos(list);
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(list));
  };

  const applyFilter = () => {
    let r = [...photos];
    if (startDate) r = r.filter(p => new Date(p.date) >= startDate);
    if (endDate) { const e = new Date(endDate); e.setHours(23,59,59); r = r.filter(p => new Date(p.date) <= e); }
    if (search.trim()) { const q = search.toLowerCase(); r = r.filter(p => (p.title+p.address+p.memo).toLowerCase().includes(q)); }
    setFiltered(r);
  };

  const updateMapMarkers = () => {
    if (!webViewRef.current) return;
    const markers = filtered.map(p => ({
      id: p.id, lat: p.latitude, lng: p.longitude,
      title: p.title, uri: p.uri,
    }));
    webViewRef.current.injectJavaScript(`updateMarkers(${JSON.stringify(markers)}); true;`);
  };

  const pickImage = async () => {
    setLoading(true);
    setGpsDetected(false);
    try {
      const r = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        quality: 0.8,
        exif: true,
        allowsEditing: false,
      });

      if (!r.canceled && r.assets[0]) {
        const asset = r.assets[0];
        setPendingImg(asset.uri);

        // EXIF에서 GPS 파싱
        const gps = parseExifGPS(asset.exif);

        if (gps) {
          // GPS 자동 인식 성공!
          setPendingLoc(gps);
          setGpsDetected(true);
          setTitle('');
          setAddress('');
          setMemo('');
          setShowAdd(true);
        } else {
          // GPS 없음
          setGpsDetected(false);
          Alert.alert(
            '📍 위치 정보 없음',
            '이 사진에 위치 태그가 없습니다.\n위치를 어떻게 추가할까요?',
            [
              {
                text: '🗺 지도에서 선택',
                onPress: () => {
                  setPinMode(true);
                  setTab('map');
                  Alert.alert('📌 핀 꽂기', '지도를 탭해서 위치를 선택하세요');
                },
              },
              {
                text: '🏠 주소 입력',
                onPress: () => {
                  setPendingLoc(null);
                  setTitle(''); setAddress(''); setMemo('');
                  setShowAdd(true);
                },
              },
              { text: '취소', style: 'cancel', onPress: () => { setPendingImg(null); } },
            ]
          );
        }
      }
    } catch (e) {
      Alert.alert('오류', '사진을 불러오는데 실패했습니다.');
    }
    setLoading(false);
  };

  const geocode = async (addr) => {
    try {
      const r = await fetch(
        `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(addr)}&format=json&limit=1`,
        { headers: { 'Accept-Language': 'ko', 'User-Agent': 'PhotoMapApp/1.0' } }
      );
      const d = await r.json();
      if (d.length) return { latitude: parseFloat(d[0].lat), longitude: parseFloat(d[0].lon) };
    } catch (e) {}
    return null;
  };

  const reverseGeocode = async (lat, lng) => {
    try {
      const r = await fetch(
        `https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lng}&format=json`,
        { headers: { 'Accept-Language': 'ko', 'User-Agent': 'PhotoMapApp/1.0' } }
      );
      const d = await r.json();
      return d.display_name || '';
    } catch (e) { return ''; }
  };

  const savePhoto = async () => {
    let loc = pendingLoc;
    if (!loc && address.trim()) {
      setLoading(true);
      loc = await geocode(address);
      setLoading(false);
      if (!loc) { Alert.alert('주소 오류', '주소를 찾을 수 없습니다'); return; }
    }
    if (!loc) { Alert.alert('위치 필요', '위치를 설정해주세요'); return; }
    if (!pendingImg) { Alert.alert('사진 필요'); return; }

    let addr = address;
    if (!addr.trim()) {
      addr = await reverseGeocode(loc.latitude, loc.longitude);
    }

    const p = {
      id: Date.now().toString(),
      uri: pendingImg,
      latitude: loc.latitude,
      longitude: loc.longitude,
      title: title.trim() || `사진 ${photos.length + 1}`,
      address: addr,
      memo,
      date: new Date().toISOString(),
      hasGps: gpsDetected,
    };

    const updated = [p, ...photos];
    await save(updated);
    setShowAdd(false);
    setPendingImg(null);
    setPendingLoc(null);
    setGpsDetected(false);
    setTitle(''); setAddress(''); setMemo('');

    webViewRef.current?.injectJavaScript(`flyTo(${loc.latitude}, ${loc.longitude}); true;`);
  };

  const deletePhoto = (id) => {
    Alert.alert('삭제', '이 사진을 삭제하시겠어요?', [
      { text: '삭제', style: 'destructive', onPress: async () => {
        const updated = photos.filter(p => p.id !== id);
        await save(updated);
        setShowDetail(false);
      }},
      { text: '취소', style: 'cancel' },
    ]);
  };

  const onMessage = (e) => {
    try {
      const data = JSON.parse(e.nativeEvent.data);
      if (data.type === 'mapClick' && pinMode) {
        setPendingLoc({ latitude: data.lat, longitude: data.lng });
        setPinMode(false);
        setTitle(''); setAddress(''); setMemo('');
        setShowAdd(true);
      } else if (data.type === 'markerClick') {
        const photo = photos.find(p => p.id === data.id);
        if (photo) { setSelected(photo); setShowDetail(true); }
      } else if (data.type === 'ready') {
        setMapReady(true);
      }
    } catch (e) {}
  };

  const fmt = (iso) => {
    const d = new Date(iso);
    return `${d.getFullYear()}.${String(d.getMonth()+1).padStart(2,'0')}.${String(d.getDate()).padStart(2,'0')}`;
  };

  const filterCount = (startDate ? 1 : 0) + (endDate ? 1 : 0) + (search ? 1 : 0);

  // 카토(Carto) 미니멀 스타일 지도
  const mapHTML = `<!DOCTYPE html>
<html><head>
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"/>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<style>
* { margin:0; padding:0; box-sizing:border-box; }
html,body,#map { width:100%; height:100%; }
.leaflet-control-attribution { font-size:9px !important; }

.m-wrap { display:flex; flex-direction:column; align-items:center; cursor:pointer; }
.m-img {
  width:48px; height:48px; border-radius:12px;
  border:3px solid #fff;
  object-fit:cover;
  box-shadow: 0 4px 12px rgba(0,0,0,0.25);
  transition: transform 0.15s;
}
.m-img:hover { transform: scale(1.08); }
.m-needle {
  width:3px; height:10px;
  background: linear-gradient(#2d6a4f, #40916c);
  border-radius:0 0 2px 2px;
  margin-top:-1px;
}
.m-dot {
  width:6px; height:6px; border-radius:50%;
  background:#2d6a4f;
  margin-top:-1px;
  box-shadow:0 1px 4px rgba(0,0,0,0.3);
}
.leaflet-popup-content-wrapper {
  border-radius:12px;
  box-shadow: 0 4px 20px rgba(0,0,0,0.15);
  border:none;
}
.leaflet-popup-content { margin:10px 14px; font-size:13px; font-weight:600; color:#1b1b1b; }
</style>
</head><body>
<div id="map"></div>
<script>
var map = L.map('map', {
  zoomControl: true,
  attributionControl: true
}).setView([${currentLat}, ${currentLng}], 13);

// Carto Voyager 스타일 (깔끔한 미니멀)
L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
  attribution: '&copy; <a href="https://carto.com/">CARTO</a>',
  subdomains: 'abcd',
  maxZoom: 20
}).addTo(map);

var markers = {};

map.on('click', function(e) {
  window.ReactNativeWebView.postMessage(JSON.stringify({
    type: 'mapClick', lat: e.latlng.lat, lng: e.latlng.lng
  }));
});

function makeIcon(uri) {
  return L.divIcon({
    className: '',
    html: '<div class="m-wrap"><img class="m-img" src="' + uri + '" onerror="this.src=\\'data:image/svg+xml,<svg xmlns=\\"http://www.w3.org/2000/svg\\" viewBox=\\"0 0 48 48\\"><rect width=\\"48\\" height=\\"48\\" rx=\\"12\\" fill=\\"\\%232d6a4f\\"/><text x=\\"24\\" y=\\"32\\" text-anchor=\\"middle\\" font-size=\\"24\\">📷</text></svg>\\'"/><div class="m-needle"></div><div class="m-dot"></div></div>',
    iconSize: [48, 70],
    iconAnchor: [24, 70],
    popupAnchor: [0, -72],
  });
}

function updateMarkers(list) {
  Object.values(markers).forEach(m => map.removeLayer(m));
  markers = {};
  list.forEach(function(p) {
    var m = L.marker([p.lat, p.lng], { icon: makeIcon(p.uri) }).addTo(map);
    m.bindPopup('<b>' + p.title + '</b>');
    m.on('click', function(e) {
      L.DomEvent.stopPropagation(e);
      window.ReactNativeWebView.postMessage(JSON.stringify({ type: 'markerClick', id: p.id }));
    });
    markers[p.id] = m;
  });
}

function flyTo(lat, lng) {
  map.flyTo([lat, lng], 16, { duration: 1.2, easeLinearity: 0.25 });
}

window.ReactNativeWebView.postMessage(JSON.stringify({ type: 'ready' }));
</script>
</body></html>`;

  return (
    <View style={s.container}>
      <StatusBar style="dark" />

      {/* 헤더 */}
      <View style={s.header}>
        <View>
          <Text style={s.htitle}>📍 포토맵</Text>
          <Text style={s.hsub}>{filtered.length}개의 사진</Text>
        </View>
        <View style={s.hbtns}>
          <TouchableOpacity style={[s.ibtn, filterCount > 0 && s.ibtnOn]} onPress={() => setShowFilter(true)}>
            <Text style={s.ibtxt}>🔍</Text>
            {filterCount > 0 && <View style={s.badge}><Text style={s.badgeTxt}>{filterCount}</Text></View>}
          </TouchableOpacity>
          <TouchableOpacity
            style={[s.ibtn, pinMode && s.ibtnOn]}
            onPress={() => {
              setPendingImg(null);
              setPinMode(!pinMode);
              if (!pinMode) Alert.alert('📌 핀 모드', '지도를 탭해서 위치를 선택하세요');
            }}
          >
            <Text style={s.ibtxt}>📌</Text>
          </TouchableOpacity>
          <TouchableOpacity style={s.addbtn} onPress={pickImage} disabled={loading}>
            {loading
              ? <ActivityIndicator color="#fff" size="small" />
              : <Text style={s.addtxt}>+ 사진</Text>
            }
          </TouchableOpacity>
        </View>
      </View>

      {/* 탭 */}
      <View style={s.tabs}>
        <TouchableOpacity style={[s.tab, tab === 'map' && s.tabOn]} onPress={() => setTab('map')}>
          <Text style={[s.tabtxt, tab === 'map' && s.tabtxtOn]}>🗺 지도</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[s.tab, tab === 'list' && s.tabOn]} onPress={() => setTab('list')}>
          <Text style={[s.tabtxt, tab === 'list' && s.tabtxtOn]}>📋 목록</Text>
        </TouchableOpacity>
      </View>

      {pinMode && (
        <View style={s.pinBanner}>
          <Text style={s.pinTxt}>📍 지도를 탭하여 위치 선택</Text>
          <TouchableOpacity onPress={() => setPinMode(false)}>
            <Text style={s.pinCancel}>취소</Text>
          </TouchableOpacity>
        </View>
      )}

      {/* 지도 */}
      {tab === 'map' && (
        <WebView
          ref={webViewRef}
          style={s.map}
          source={{ html: mapHTML }}
          onMessage={onMessage}
          javaScriptEnabled
          domStorageEnabled
          originWhitelist={['*']}
          mixedContentMode="always"
          onLoad={() => { if (filtered.length > 0) setTimeout(updateMapMarkers, 500); }}
        />
      )}

      {/* 목록 */}
      {tab === 'list' && (
        <ScrollView style={s.list} contentContainerStyle={{ paddingBottom: 20 }}>
          {filtered.length === 0 ? (
            <View style={s.empty}>
              <Text style={{ fontSize: 60, marginBottom: 12 }}>🏞</Text>
              <Text style={s.emptyT}>사진이 없습니다</Text>
              <Text style={s.emptyD}>+ 사진 버튼으로 추가해보세요</Text>
            </View>
          ) : filtered.map(p => (
            <TouchableOpacity key={p.id} style={s.item} onPress={() => { setSelected(p); setShowDetail(true); }}>
              <Image source={{ uri: p.uri }} style={s.thumb} />
              <View style={s.info}>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4, marginBottom: 3 }}>
                  <Text style={s.ititle} numberOfLines={1}>{p.title}</Text>
                  {p.hasGps && <Text style={{ fontSize: 10, color: C.accentLight }}>📡GPS</Text>}
                </View>
                <Text style={s.iaddr} numberOfLines={2}>{p.address || '주소 없음'}</Text>
                <Text style={s.idate}>{fmt(p.date)}</Text>
              </View>
              <TouchableOpacity
                style={s.gotoBtn}
                onPress={() => {
                  setTab('map');
                  setTimeout(() => webViewRef.current?.injectJavaScript(`flyTo(${p.latitude}, ${p.longitude}); true;`), 300);
                }}
              >
                <Text style={{ fontSize: 20 }}>📍</Text>
              </TouchableOpacity>
            </TouchableOpacity>
          ))}
        </ScrollView>
      )}

      {/* 추가 모달 */}
      <Modal visible={showAdd} animationType="slide" transparent>
        <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1 }}>
          <View style={s.overlay}>
            <View style={s.sheet}>
              <View style={s.handle} />
              <Text style={s.mtitle}>사진 추가</Text>

              {pendingImg && <Image source={{ uri: pendingImg }} style={s.preview} resizeMode="cover" />}

              {/* GPS 자동 인식 배지 */}
              {gpsDetected && (
                <View style={s.gpsBadge}>
                  <Text style={s.gpsBadgeTxt}>📡 위치 태그 자동 인식됨</Text>
                </View>
              )}

              <Text style={s.label}>제목</Text>
              <TextInput style={s.input} value={title} onChangeText={setTitle} placeholder="제목 (선택)" placeholderTextColor={C.muted} />

              {!pendingLoc ? (
                <>
                  <Text style={s.label}>주소 검색</Text>
                  <View style={{ flexDirection: 'row', gap: 8 }}>
                    <TextInput
                      style={[s.input, { flex: 1, marginBottom: 0 }]}
                      value={address} onChangeText={setAddress}
                      placeholder="예: 서울시 강남구 역삼동"
                      placeholderTextColor={C.muted}
                    />
                    <TouchableOpacity
                      style={s.pinbtn}
                      onPress={() => { setShowAdd(false); setPinMode(true); setTab('map'); Alert.alert('📌', '지도를 탭해서 위치를 선택하세요'); }}
                    >
                      <Text style={{ fontSize: 20 }}>📌</Text>
                    </TouchableOpacity>
                  </View>
                </>
              ) : (
                <View style={s.locset}>
                  <Text style={s.locsetT}>
                    {gpsDetected ? '📡 GPS 자동 인식' : '✅ 위치 설정됨'}
                    {'\n'}
                    <Text style={{ fontSize: 11, opacity: 0.8 }}>
                      {pendingLoc.latitude.toFixed(5)}, {pendingLoc.longitude.toFixed(5)}
                    </Text>
                  </Text>
                  <TouchableOpacity onPress={() => { setPendingLoc(null); setGpsDetected(false); }}>
                    <Text style={{ color: C.accent, fontSize: 12 }}>변경</Text>
                  </TouchableOpacity>
                </View>
              )}

              <Text style={s.label}>메모</Text>
              <TextInput
                style={[s.input, { height: 60, textAlignVertical: 'top' }]}
                value={memo} onChangeText={setMemo}
                placeholder="메모 (선택)" placeholderTextColor={C.muted} multiline
              />

              <View style={s.mbtns}>
                <TouchableOpacity style={[s.mbtn, s.mbtnC]} onPress={() => { setShowAdd(false); setPendingImg(null); setPendingLoc(null); setGpsDetected(false); }}>
                  <Text style={s.mbtnCT}>취소</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[s.mbtn, s.mbtnA]} onPress={savePhoto} disabled={loading}>
                  {loading ? <ActivityIndicator color="#fff" /> : <Text style={s.mbtnAT}>저장</Text>}
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </KeyboardAvoidingView>
      </Modal>

      {/* 상세 모달 */}
      <Modal visible={showDetail} animationType="slide" transparent>
        <View style={s.overlay}>
          <View style={s.sheet}>
            <View style={s.handle} />
            {selected && <>
              <Image source={{ uri: selected.uri }} style={s.detailImg} resizeMode="cover" />
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 4 }}>
                <Text style={s.dtitle}>{selected.title}</Text>
                {selected.hasGps && <Text style={{ fontSize: 11, color: C.accentLight, fontWeight: '600' }}>📡GPS</Text>}
              </View>
              <Text style={s.dinfo}>📍 {selected.address || '주소 없음'}</Text>
              <Text style={s.dinfo}>🕐 {fmt(selected.date)}</Text>
              {selected.memo ? <Text style={s.dinfo}>📝 {selected.memo}</Text> : null}
              <View style={s.mbtns}>
                <TouchableOpacity style={[s.mbtn, s.mbtnC]} onPress={() => setShowDetail(false)}>
                  <Text style={s.mbtnCT}>닫기</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[s.mbtn, { backgroundColor: C.red }]} onPress={() => deletePhoto(selected.id)}>
                  <Text style={s.mbtnAT}>🗑 삭제</Text>
                </TouchableOpacity>
              </View>
            </>}
          </View>
        </View>
      </Modal>

      {/* 필터 모달 */}
      <Modal visible={showFilter} animationType="slide" transparent>
        <View style={s.overlay}>
          <View style={s.sheet}>
            <View style={s.handle} />
            <Text style={s.mtitle}>🔍 검색 및 필터</Text>
            <Text style={s.label}>키워드</Text>
            <TextInput style={s.input} value={search} onChangeText={setSearch} placeholder="제목, 주소, 메모" placeholderTextColor={C.muted} />
            <Text style={s.label}>시작 날짜</Text>
            <TouchableOpacity style={s.datebtn} onPress={() => setShowStart(true)}>
              <Text style={s.datetxt}>{startDate ? startDate.toLocaleDateString('ko-KR') : '날짜 선택'}</Text>
            </TouchableOpacity>
            <Text style={s.label}>종료 날짜</Text>
            <TouchableOpacity style={s.datebtn} onPress={() => setShowEnd(true)}>
              <Text style={s.datetxt}>{endDate ? endDate.toLocaleDateString('ko-KR') : '날짜 선택'}</Text>
            </TouchableOpacity>
            <View style={s.mbtns}>
              <TouchableOpacity style={[s.mbtn, s.mbtnC]} onPress={() => { setStartDate(null); setEndDate(null); setSearch(''); }}>
                <Text style={s.mbtnCT}>초기화</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[s.mbtn, s.mbtnA]} onPress={() => setShowFilter(false)}>
                <Text style={s.mbtnAT}>적용</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      <DateTimePickerModal isVisible={showStart} mode="date" onConfirm={d => { setStartDate(d); setShowStart(false); }} onCancel={() => setShowStart(false)} locale="ko" />
      <DateTimePickerModal isVisible={showEnd} mode="date" onConfirm={d => { setEndDate(d); setShowEnd(false); }} onCancel={() => setShowEnd(false)} locale="ko" />
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: C.bg },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', backgroundColor: C.surface, paddingHorizontal: 16, paddingTop: Platform.OS === 'android' ? 44 : 52, paddingBottom: 12, borderBottomWidth: 1, borderBottomColor: C.border, shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.06, shadowRadius: 4, elevation: 3 },
  htitle: { color: C.text, fontSize: 20, fontWeight: '800', letterSpacing: -0.5 },
  hsub: { color: C.muted, fontSize: 12, marginTop: 2 },
  hbtns: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  ibtn: { width: 38, height: 38, borderRadius: 10, backgroundColor: C.card, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: C.border },
  ibtnOn: { borderColor: C.accent, backgroundColor: C.accentSoft },
  ibtxt: { fontSize: 18 },
  badge: { position: 'absolute', top: -4, right: -4, width: 16, height: 16, borderRadius: 8, backgroundColor: C.red, alignItems: 'center', justifyContent: 'center' },
  badgeTxt: { color: '#fff', fontSize: 10, fontWeight: '700' },
  addbtn: { backgroundColor: C.accent, paddingHorizontal: 14, paddingVertical: 8, borderRadius: 10, minWidth: 64, alignItems: 'center' },
  addtxt: { color: '#fff', fontWeight: '700', fontSize: 14 },
  tabs: { flexDirection: 'row', backgroundColor: C.surface, borderBottomWidth: 1, borderBottomColor: C.border },
  tab: { flex: 1, paddingVertical: 10, alignItems: 'center' },
  tabOn: { borderBottomWidth: 2, borderBottomColor: C.accent },
  tabtxt: { color: C.muted, fontSize: 14 },
  tabtxtOn: { color: C.accent, fontWeight: '700' },
  pinBanner: { backgroundColor: C.accent, paddingVertical: 8, paddingHorizontal: 16, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  pinTxt: { color: '#fff', fontWeight: '600', fontSize: 13 },
  pinCancel: { color: 'rgba(255,255,255,0.85)', fontSize: 13, textDecorationLine: 'underline' },
  map: { flex: 1 },
  list: { flex: 1, backgroundColor: '#f5f5f0', paddingTop: 8, paddingHorizontal: 12 },
  empty: { alignItems: 'center', paddingTop: 80 },
  emptyT: { color: C.text, fontSize: 18, fontWeight: '700', marginBottom: 8 },
  emptyD: { color: C.muted, fontSize: 14 },
  item: { flexDirection: 'row', backgroundColor: C.surface, borderRadius: 14, marginBottom: 10, overflow: 'hidden', borderWidth: 1, borderColor: C.border, shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.05, shadowRadius: 3, elevation: 2 },
  thumb: { width: 80, height: 80 },
  info: { flex: 1, padding: 10, justifyContent: 'center' },
  ititle: { color: C.text, fontSize: 14, fontWeight: '600' },
  iaddr: { color: C.muted, fontSize: 11, marginBottom: 3, lineHeight: 16 },
  idate: { color: C.accentLight, fontSize: 11, fontWeight: '500' },
  gotoBtn: { padding: 10, justifyContent: 'center', alignItems: 'center', width: 44 },
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.45)', justifyContent: 'flex-end' },
  sheet: { backgroundColor: C.surface, borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 20, paddingBottom: Platform.OS === 'ios' ? 34 : 20, maxHeight: height * 0.9 },
  handle: { width: 36, height: 4, backgroundColor: C.border, borderRadius: 2, alignSelf: 'center', marginBottom: 16 },
  mtitle: { color: C.text, fontSize: 18, fontWeight: '800', marginBottom: 16 },
  label: { color: C.muted, fontSize: 12, marginBottom: 6, marginTop: 10, fontWeight: '600', textTransform: 'uppercase', letterSpacing: 0.5 },
  input: { backgroundColor: C.card, borderRadius: 12, padding: 12, color: C.text, fontSize: 14, borderWidth: 1, borderColor: C.border, marginBottom: 4 },
  pinbtn: { width: 44, height: 44, backgroundColor: C.card, borderRadius: 12, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: C.border },
  gpsBadge: { backgroundColor: C.accentSoft, borderRadius: 8, padding: 8, marginBottom: 4, alignItems: 'center' },
  gpsBadgeTxt: { color: C.accent, fontSize: 13, fontWeight: '700' },
  locset: { backgroundColor: C.accentSoft, borderRadius: 12, padding: 12, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 },
  locsetT: { color: C.accent, fontSize: 13, fontWeight: '600', flex: 1, lineHeight: 18 },
  datebtn: { backgroundColor: C.card, borderRadius: 12, padding: 12, borderWidth: 1, borderColor: C.border, marginBottom: 4 },
  datetxt: { color: C.text, fontSize: 14 },
  mbtns: { flexDirection: 'row', gap: 10, marginTop: 16 },
  mbtn: { flex: 1, padding: 14, borderRadius: 12, alignItems: 'center' },
  mbtnC: { backgroundColor: C.card, borderWidth: 1, borderColor: C.border },
  mbtnCT: { color: C.muted, fontWeight: '600' },
  mbtnA: { backgroundColor: C.accent },
  mbtnAT: { color: '#fff', fontWeight: '700' },
  preview: { width: '100%', height: 160, borderRadius: 14, marginBottom: 4 },
  detailImg: { width: '100%', height: 200, borderRadius: 14, marginBottom: 14 },
  dtitle: { color: C.text, fontSize: 18, fontWeight: '800' },
  dinfo: { color: C.muted, fontSize: 13, marginBottom: 6, lineHeight: 18 },
});
