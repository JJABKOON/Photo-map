# 📍 포토맵 (Photo Map App)

사진을 지도 위에 정리하는 Android 앱입니다.

## ✨ 기능

- 🗺 **지도 보기** — 추가한 사진이 지도 위에 썸네일 핀으로 표시
- 📸 **사진 추가** — 갤러리에서 사진 선택, EXIF GPS 자동 인식
- 📌 **핀 꽂기** — GPS 없는 사진은 지도를 직접 탭해서 위치 지정
- 🏠 **주소 검색** — 주소 입력으로 위치 설정 (OpenStreetMap Nominatim)
- 🔍 **시간 필터** — 날짜 범위로 사진 검색
- 📋 **목록 보기** — 전체 사진 목록 + 해당 위치로 지도 이동

---

## 🚀 APK 빌드 방법 (핸드폰만으로!)

### 1단계: GitHub 리포지토리 준비

1. GitHub 앱(또는 브라우저)에서 새 리포지토리 생성
2. 이 ZIP 파일을 리포지토리에 업로드

### 2단계: Expo 토큰 등록

1. [expo.dev](https://expo.dev) 에 가입 (무료)
2. **Account Settings → Access Tokens → Create Token**
3. GitHub 리포지토리 → **Settings → Secrets → Actions**
4. `EXPO_TOKEN` 이름으로 토큰 추가

### 3단계: ZIP 업로드 → 자동 빌드

1. GitHub 리포지토리에 `photo-map-app.zip` 을 커밋/푸시
2. **Actions 탭** → 워크플로우 자동 시작
3. 완료 후 **Artifacts** 에서 APK 다운로드

> 첫 빌드는 10~15분 소요됩니다.

---

## 📁 파일 구조

```
photo-map-app/
├── App.js                          # 메인 앱 코드
├── app.json                        # Expo 설정
├── eas.json                        # EAS 빌드 설정
├── package.json                    # 의존성
├── babel.config.js
└── .github/
    └── workflows/
        └── build.yml               # GitHub Actions 워크플로우
```

---

## 🛠 로컬 개발 (선택)

```bash
npm install
npx expo start
```

---

## 📝 사용된 기술

- **React Native + Expo** — 크로스 플랫폼 앱
- **react-native-maps** — 지도 (Google Maps)
- **expo-image-picker** — 갤러리 접근 + EXIF 읽기
- **expo-location** — GPS 위치
- **Nominatim (OpenStreetMap)** — 무료 지오코딩
- **AsyncStorage** — 로컬 데이터 저장
- **EAS Build** — Expo 클라우드 APK 빌드
